import os
import IPython
import random
import math
import pickle
import operator, re
import seaborn as sns
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pylab as pl
import statsmodels.api as sm
import parfit.parfit as pf
from pprint import pprint
from google.colab import files
from collections import Counter
from imblearn.pipeline import make_pipeline
from imblearn.over_sampling import (SMOTE,SVMSMOTE,ADASYN)
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
from sklearn.svm import LinearSVC
from sklearn.linear_model import Perceptron
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn import linear_model
from sklearn.model_selection import ParameterGrid
from sklearn.kernel_approximation import Nystroem
from sklearn.model_selection import (train_test_split,RandomizedSearchCV, GridSearchCV)
from sklearn.feature_selection import SelectFromModel
from sklearn.feature_selection import SelectKBest,f_classif
from sklearn.preprocessing import StandardScaler
from sklearn.utils import class_weight
from sklearn import metrics
from sklearn.metrics import (roc_curve, auc, roc_auc_score, accuracy_score, classification_report, confusion_matrix, precision_score, recall_score, f1_score, mean_squared_error, mean_absolute_error)
from pprint import pprint
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score
from sklearn.externals import joblib
from json2html import *

from keras.models import Sequential
from tensorflow.keras import layers
from keras.layers import Dense, Dropout, Embedding, Flatten, Activation
from keras.layers import LSTM, SimpleRNN, GRU, Convolution1D,MaxPooling1D
from keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, TerminateOnNaN, LearningRateScheduler
from keras.models import load_model
from keras.utils.vis_utils import plot_model
from keras.wrappers.scikit_learn import KerasClassifier
from multiprocessing import Queue
from tpot import TPOTClassifier

from lib.Config import *

datasets={}
models = []

def loadModel(model, h5=False, json=False):
  if h5:
    return tf.keras.models.load_model(machine_learning_models_path + model + '.h5')
  if json:
    with open(machine_learning_models_path + model + '.txt', 'rb') as openfile: 
      return pickle.load(openfile)
  else:
    return joblib.load(machine_learning_models_path + model + '.sav')

def loadKerasModel(model):
  return tf.keras.models.load_model(machine_learning_models_path + model + '.h5')

def saveModel(model, fileName, h5=False, json=False):
  path = None

  if h5:
    path = machine_learning_models_path + fileName + '.h5'
    model.save(path)
  if json:
    path = machine_learning_models_path + fileName + '.txt'
    with open(path, 'wb') as outfile: 
      pickle.dump(model, outfile) 
  else:
    path = machine_learning_models_path + fileName + '.sav'
    joblib.dump(model, path)

  print("\nModel saved to {}\n".format(path))

def saveDocument(fileName):
  if fileName:
    output = documentation_path + "MachineLearning"
    doc = notebooks_path + "MachineLearning.ipynb"
    command = "jupyter nbconvert --log-level 0 --output " + fileName + " --output-dir='" + output + "' '" + doc + "'"
    os.system(command)
    print("File saved to {}/{}.html".format(output,fileName))
  else:
    print("Set notebook name")

def plotModel(model, filename):
  tf.keras.utils.plot_model(model, to_file = machine_learning_models_path + filename + '.png', show_shapes=True, show_layer_names=True, expand_nested=True)

def trainingHistoryVisualization(history, title):
  sns.set(style="whitegrid")
  rcParams['figure.figsize'] = 15, 8
  plt.figure()
  plt.plot(history.history['acc'])
  plt.plot(history.history['val_acc'])
  plt.title(title + ' Model Accuracy')
  plt.ylabel('Accuracy')
  plt.xlabel('Epoch')
  plt.legend(['Train', 'Valid'], loc='lower right')
  plt.show()
  print("\n")
  plt.figure()
  plt.plot(history.history['loss'])
  plt.plot(history.history['val_loss'])
  plt.title(title + ' Model Loss')
  plt.ylabel('Loss')
  plt.xlabel('Epoch')
  plt.legend(['Train', 'Valid'], loc='upper right')
  plt.show()

def KBestFeatures(topFeatures,dataset):
  if topFeatures > 0 and topFeatures <= dataset.shape[1]:
    y = dataset.label
    X = dataset.drop('label', axis=1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    X_train, X_valid, y_train, y_valid = train_test_split(X_train, y_train, test_size=0.2, random_state=1)
    KBestFeatures = SelectKBest(f_classif, k=topFeatures)
    KBestFeatures_fit = KBestFeatures.fit(X_train,y_train)
    dfscores = pd.DataFrame(KBestFeatures_fit.scores_)
    dfcolumns = pd.DataFrame(X_train.columns)
    featureScores = pd.concat([dfcolumns,dfscores],axis=1)
    featureScores.columns = ['Feature','Score']
    featureScores = featureScores.round(2)
    top_features = featureScores.nlargest(topFeatures,'Score')
    top_features.sort_values(by=['Score'],ascending=False,inplace=True)
    top_features_list = list(top_features['Feature'])
    top_features_list.append('label')
    dataset = dataset[top_features_list]
    return dataset, top_features
  else:
    error = "Top features must be in range (0," + str(dataset.shape[1]) + ">"
    return error

def containsAny(features, c):
  arr = []
  wildcard = []
  for f in features:
    if operator.contains(f, c): 
      wildcard.append(re.sub('\*', '', f))
    else:
      arr.append(f)
  return arr, wildcard

def MyTopFeatures(myTopFeatures,dataset):
  features = parsePreprocessedDatasetsNames(myTopFeatures)
  features = uniqueList(features)
  features, wildcards = containsAny(features,'*')

  if wildcards:
    for w in wildcards:
      wild_list = list(dataset.filter(regex=w).columns)
      features.extend(wild_list)

  features.append('label')
  dataset = dataset[features]
  return dataset, features

def TreeBasedModelHyperparameterSelector(X_train, y_train, rand=False, iteration=5, cross_val=5, jobs=-1, verbose_lvl=0, start_val=50, stop_val=100, samples=5, randomForest=False, decisionTree=False, xgboost=False):
  from pprint import pprint

  a=5
  b=20

  if rand:
    n_estimators = [int(x) for x in random.sample(range(start_val, stop_val), samples)]
    min_samples_split = [int(x) for x in random.sample(range(a, b), samples)]
    min_samples_leaf = [int(x) for x in random.sample(range(a, b+samples), samples)]
    max_depth = [int(x) for x in random.sample(range(samples, int(stop_val/2)), samples)]
  else:
    n_estimators = [int(x) for x in np.linspace(start_val, stop_val, samples)]
    min_samples_split = [int(x) for x in np.linspace(a, b, samples)]
    min_samples_leaf = [int(x) for x in np.linspace(a, b+samples, samples)]
    max_depth = [int(x) for x in np.linspace(samples, stop_val/2, samples)]
    
  learning_rate = [round(float(x),4) for x in np.linspace(0.001, 0.1, samples)]
  subsample = [round(float(x),2) for x in np.linspace(0.1, 1, samples)]
  min_impurity_decrease = [round(float(x),2) for x in np.linspace(0, 1, samples)]
  validation_fraction = [round(float(x),2) for x in np.linspace(0.01, 0.9, samples)]
  max_leaf_nodes = [int(x) for x in np.linspace(a, 25, samples)]
  max_leaf_nodes.append(None)
  max_depth.append(None)
  
  booster = ['gbtree', 'gblinear', 'dart']
  tree_method = ['auto', 'exact', 'approx', 'gpu_hist']
  sampling_method = ['uniform', 'gradient_based']
  scoring = ['auc']
  objective = ['binary:hinge']

  criterion_gradient_boosting = ['friedman_mse','mse','mae']
  criterion = ['gini', 'entropy']
  max_features = ['auto', 'sqrt', 'log2']
  splitter = ['best', 'random']
  bootstrap = [True, False]
  warm_start = [True,False]
  oob_score = [True,False]

  if randomForest:
    grid = {'n_estimators': n_estimators,
            'criterion': criterion,
            'bootstrap': bootstrap,
            'max_features': max_features,
            'max_depth': max_depth,
            'min_samples_split': min_samples_split,
            'min_samples_leaf': min_samples_leaf}
            #'warm_start': warm_start,
            #'max_leaf_nodes': max_leaf_nodes,
            #'min_impurity_decrease': min_impurity_decrease,
            #'oob_score': oob_score,
  if decisionTree:
    grid = {'criterion': criterion,
            'splitter': splitter,
            'max_features': max_features,
            'max_depth': max_depth,
            'min_samples_split': min_samples_split,
            'min_samples_leaf': min_samples_leaf}
            #'max_leaf_nodes': max_leaf_nodes,
            #'min_impurity_decrease': min_impurity_decrease,
  if xgboost:
      grid = {#'eta': learning_rate,
              #'subsample': subsample,
              'n_estimators': n_estimators,
              'max_depth': max_depth,
              'tree_method': tree_method,
              'sampling_method': sampling_method,
              'scoring': scoring,
              'objective': objective}

  model = None
  if randomForest:
    model = RandomForestClassifier()
  if decisionTree:
    model = DecisionTreeClassifier()
  if xgboost:
    #model = GradientBoostingClassifier()
    model = XGBClassifier()
  
  print("\nRandom Search\n")
  pprint(grid)
  print("\n")
  random_search = RandomizedSearchCV(estimator = model, param_distributions = grid, n_iter = iteration, cv = cross_val, n_jobs=jobs, verbose = verbose_lvl)
  randomSearch_result = random_search.fit(X_train, y_train)
  params = randomSearch_result.best_params_
  
  if randomForest:
    params_n_estimators = params['n_estimators']
    params_bootstrap = params['bootstrap']
    #params_warm_start = params['warm_start']
    #params_oob_score = params['oob_score']
  if decisionTree:
    params_splitter = params['splitter']
    #params_min_impurity_decrease = params['min_impurity_decrease']
    #params_max_leaf_nodes = params['max_leaf_nodes']
  if xgboost: 
    #params_learning_rate = params['eta']
    #params_subsample = params['subsample']
    params_n_estimators = params['n_estimators']
    params_tree_method = params['tree_method']
    params_sampling_method = params['sampling_method']
    params_scoring = params['scoring']
    params_objective = params['objective']
  
  if randomForest or decisionTree:
    params_criterion = params['criterion']
    params_max_features = params['max_features']
    params_min_samples_split = params['min_samples_split']
    params_min_samples_leaf = params['min_samples_leaf']

  params_max_depth = params['max_depth']

  stop_val=math.ceil(stop_val/2)
  samples=math.ceil(samples/2)

  if randomForest:
    n_estimators = [int(x) for x in np.linspace(params_n_estimators, params_n_estimators+stop_val, samples)]
    bootstrap = [params_bootstrap]
    #warm_start = [params_warm_start]
    #oob_score = [params_oob_score]
  if decisionTree:
    splitter = [params_splitter]
    #min_impurity_decrease = [round(float(x),2) for x in np.linspace(params_min_impurity_decrease, (1-params_min_impurity_decrease) + params_min_impurity_decrease, samples)]
    #if params_max_leaf_nodes is not None:
    #  max_leaf_nodes = [int(x) for x in np.linspace(params_max_leaf_nodes, params_max_leaf_nodes + b, num = samples)]
    #else:
    #  max_leaf_nodes = [params_max_leaf_nodes]
  if xgboost:
    n_estimators = [int(x) for x in np.linspace(params_n_estimators, params_n_estimators+stop_val, samples)]
    #if params_learning_rate == 1.0:
    #  learning_rate = [params_learning_rate]
    #else:
    #  learning_rate = [round(float(x),4) for x in np.linspace(params_learning_rate, (0.1 - params_learning_rate) + params_learning_rate, samples)]
    #if params_subsample == 1.0:
    #  subsample = [params_subsample]
    #else:
    #  subsample = [round(float(x),2) for x in np.linspace(params_subsample, (1-params_subsample) + params_subsample, samples)]
    tree_method = [params_tree_method]
    sampling_method = [params_sampling_method]
    scoring = [params_scoring]
    objective = [params_objective]

  if randomForest or decisionTree:
    criterion = [params_criterion]
    max_features = [params_max_features]
    min_samples_split = [int(x) for x in np.linspace(start = params_min_samples_split, stop = params_min_samples_split+stop_val, num = samples)]
    min_samples_leaf = [int(x) for x in np.linspace(start = params_min_samples_leaf, stop = params_min_samples_leaf+stop_val, num = samples)]
    
  if params_max_depth is not None:
    max_depth = [int(x) for x in np.linspace(start= params_max_depth, stop= params_max_depth+stop_val, num = samples)]
  else:
    max_depth = [params_max_depth]

  if randomForest:
    grid = {'n_estimators': n_estimators,
            'criterion': criterion,
            'bootstrap': bootstrap,
            'max_features': max_features,
            'max_depth': max_depth,
            'min_samples_split': min_samples_split,
            'min_samples_leaf': min_samples_leaf}
  if decisionTree:
    grid = {'criterion': criterion,
            'splitter': splitter,
            'max_features': max_features,
            'max_depth': max_depth,
            'min_samples_split': min_samples_split,
            'min_samples_leaf': min_samples_leaf}
  if xgboost:
    grid = {'n_estimators': n_estimators,
            'max_depth': max_depth,
            'tree_method': tree_method,
            'sampling_method': sampling_method,
            'scoring': scoring,
            'objective': objective}

  print("\nGrid Search\n")
  pprint(grid)
  print("\n")
  grid_search = GridSearchCV(estimator = model, param_grid = grid, cv = cross_val, n_jobs=jobs, verbose = verbose_lvl)
  gridSearch_result = grid_search.fit(X_train, y_train)
  print("\nHyperparameters\n")
  pprint(gridSearch_result.best_params_)
  return gridSearch_result.best_params_
  
def parsePreprocessedDatasetsNames(datasets_to_load):
  return [x.strip() for x in datasets_to_load.split(',')]

def uniqueList(dfs): 
  unique_list = []  
  for x in dfs:
    if x not in unique_list:
      unique_list.append(x)
  return unique_list

def loadPreprocessedDatasets(datasets_to_load,datasets_to_merge,merge):
  try:
    print("Loading dataset/s...\n")
    if datasets_to_load:
      datasets.clear()
      datasets_to_load = parsePreprocessedDatasetsNames(datasets_to_load)
      datasets_to_merge = parsePreprocessedDatasetsNames(datasets_to_merge)
      datasets_to_load = uniqueList(datasets_to_load)
      datasets_to_merge = uniqueList(datasets_to_merge)

      for d in datasets_to_load:
        df_name = d.split(".")[0]
        datasets[df_name] = pd.read_csv(preprocessed_dataset_path + d + '.csv', delimiter=',', encoding='utf-8', low_memory=False, skipinitialspace=True, skip_blank_lines=True, verbose=False);
      
      if merge and (len(datasets_to_load) > 1) and (len(datasets_to_merge) >= 2):
        print("Merging datasets...")
        frames=[]
        dimension = datasets[datasets_to_merge[0]].shape[1]
        
        for df in datasets_to_merge:
          if datasets[df].shape[1] == dimension:
            frames.append(datasets[df])
          else:
            raise ValueError('Some datasets has not have equal dimensions. Excepted {}, got {}'.format(dimension,datasets[df].shape[1]))
          
        dataset = pd.concat(frames)
        dataset = dataset.sample(frac=1).reset_index(drop=True)
        datasets['mergedDataset'] = dataset
        print("Merging datasets done\n")
      else:
        print("Merging datasets failed")

      print("Datasets:")
      for d in datasets:
        print(d)
        getDatasetDimensions(datasets[d])
        
      print("To access dataset use datasets[\'datasetName\']\n\nLoaded datasets are:")
      i=1
      for d in list(datasets):
        print("{}. {}".format(i,d))
        i+=1
    else:
      print("Set datasets to load")
  except (FileNotFoundError,ValueError) as e:
    return e

def getDatasetDimensions(dataset):
  print("Rows: {}\nColumns: {}\n".format(dataset.shape[0],dataset.shape[1]))

def analyzeDataset(dataset, title):
  attack_traffic=dataset[dataset.label.apply(lambda x: x==1)]
  normal_traffic=dataset[dataset.label.apply(lambda x: x==0)]
  total_features=dataset.shape[1];
  total_rows=dataset.shape[0];
  normal_traffic_rows=normal_traffic.shape[0];
  normal_traffic_per=(100*normal_traffic_rows)/total_rows;
  attack_traffic_rows=attack_traffic.shape[0];
  attack_traffic_per=(100*attack_traffic_rows)/total_rows;

  print(title)
  print("Total rows: {}\nTotal features: {}\nNormal traffic: {} ({} %)\nAttack traffic: {} ({} %)".
        format(total_rows, total_features, normal_traffic_rows, float("{0:.2f}".format(normal_traffic_per)), attack_traffic_rows, float("{0:.2f}".format(attack_traffic_per))));

  count_classes = pd.value_counts(dataset.label)
  sns.set(style="whitegrid")
  rcParams['figure.figsize'] = 15, 8
  plt.figure()
  count_classes.plot(kind="bar")
  plt.title(title + " - Normal vs Attack class distibution")
  plt.xticks(range(2), ["Normal","Attack"])
  plt.xlabel("Class")
  plt.ylabel("Frequency")
  print("\n")

def handleNaNcolumns():
  for d in datasets:
    dataset=datasets[d]
    print("{} - NaN columns: {}\n".format(d,dataset.columns[dataset.isna().any()].tolist()))

def splitDataset(dataset):
  y = dataset.label
  X = dataset.drop('label', axis=1)

  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
  X_train, X_valid, y_train, y_valid = train_test_split(X_train, y_train, test_size=0.2, random_state=1)

  print("Train set: {}\nValidation set: {}\nTest set: {}\n".format(X_train.shape[0],X_valid.shape[0],X_test.shape[0]))
  return X_train, y_train, X_valid, y_valid, X_test, y_test

def getClassWeights(y_train):
  class_weights_arr = class_weight.compute_class_weight('balanced',np.unique(y_train),y_train)
  class_weights = {};

  i=0
  for cw in class_weights_arr:
    class_weights[i] = cw;
    i+=1

  return class_weights

def getCorelationMatrix(X_train, title):
  corrmat = X_train.corr()
  top_corr_features = corrmat.index
  pl.title(title)
  pl.figure(figsize=(60,60))
  g=sns.heatmap(X_train[top_corr_features].corr(method='pearson', min_periods=1),annot=True,cmap="RdYlGn")

def plot_roc_curve(fpr, tpr, title):
  sns.set(style="whitegrid")
  rcParams['figure.figsize'] = 15, 8
  plt.figure()
  plt.plot(fpr, tpr, color='orange', label='ROC')
  plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Receiver Operating Characteristic Curve ' + title)
  plt.legend()
  plt.show()

def predict(clf, X, y, title):
  print("\n",title,"\n")

  params = clf.get_params()
  prediction = clf.predict(X)
  accuracy = accuracy_score(y, prediction)
  accuracy_mean = clf.score(X, y)
  f1 = f1_score(y, prediction, average='binary')
  accuracy *= 100
  f1 *= 100

  # Accuracy classification score - accuracy_score
  # In multilabel classification, this function computes subset accuracy: the set of labels predicted for a sample must exactly match the corresponding set of labels in y_true.
  
  # Score - Return the mean accuracy on the given test data and labels

  print("Accuracy score: %.2f%%\n" % (accuracy))
  print("F1-score: %.2f%%\n" % (f1))

  cv = cross_val_score(clf, X, y, cv=10, n_jobs=-1, scoring='roc_auc')
  print("Standard 10 x Cross-validation accuracy: %.2f%% (+/- %.2f)" % (cv.mean()*100, ((cv.std()*2)*100)))

  skfold = StratifiedKFold(n_splits=10)

  skfold_cv = cross_val_score(clf, X, y, cv=skfold, n_jobs=-1, scoring='roc_auc')
  print("Stratified 10 x K-fold Cross-validation accuracy: %.2f%% (+/- %.2f)\n" % (skfold_cv.mean()*100, ((skfold_cv.std()*2)*100)))

  print("\nClassification Report\n {}\n".format(classification_report(y, prediction, digits=4)))

  print("\nConfusion-matrix\n {}\n".format(pd.crosstab(y, prediction, rownames=['Actual Species'], colnames=['Predicted Species'])))

  '''
  conf_mat = confusion_matrix(y, prediction)
  sns.heatmap(conf_mat,annot=True)
  plt.title("Confusion-matrix")
  plt.figure(figsize=(20,20))
  plt.show()
  '''
  
  proba = clf.predict_proba(X)
  proba = [p[1] for p in proba]
  auc = roc_auc_score(y, proba)
  auc *= 100
  print("ROC-AUC: %.2f%%\n" % (auc))

  fpr, tpr, thresholds = roc_curve(y.values, proba)
  #plot_roc_curve(fpr, tpr)
  sns.set(style="whitegrid")
  rcParams['figure.figsize'] = 15, 8
  plt.figure()
  plt.plot(fpr, tpr, color='darkorange', label='ROC-AUC = %0.2f' % (auc))
  plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Receiver Operating Characteristic Curve - ' + title)
  plt.legend(loc="lower right")
  plt.show()
  return accuracy,f1,auc,fpr,tpr

def predictNN(nn_model, X, y, title):
  print("\nEvaluating Neural Network")

  #Loss is the penalty for a bad prediction. That is, loss is a number indicating how bad the model's prediction was on a single example. If the model's prediction is perfect, the loss is zero; otherwise, the loss is greater.
  loss, accuracy = nn_model.evaluate(X, y, batch_size=1)
  y_pred = nn_model.predict(X, batch_size=1, verbose=1)
  y_pred_new = (y_pred>0.5).astype(np.int32)
  f1 = f1_score(y, y_pred_new)

  accuracy *= 100
  loss *= 100
  f1 *= 100
  #prediction = np.argmax(y_pred_new, axis=1)

  print("\nAccuracy: %.2f%%" % (accuracy))
  print("F1-score: %.2f%%" % (f1))
  print("Loss: %.2f%%\n" % (loss))
  print("\nClassification Report\n {}\n".format(classification_report(y, y_pred_new, digits=4)))
  print("\nConfusion-matrix\n {}\n".format(pd.crosstab(y, y_pred_new[:, 0], rownames=['Actual Species'], colnames=['Predicted Species'])))
  
  fpr, tpr, thresholds = roc_curve(y, y_pred_new)
  auc = metrics.auc(fpr, tpr)
  auc *= 100
  print("ROC-AUC: %.2f%%\n" % (auc))

  sns.set(style="whitegrid")
  rcParams['figure.figsize'] = 15, 8
  plt.figure()
  plt.plot(fpr, tpr, color='darkorange', label='ROC-AUC = %0.2f' % (auc))
  plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Receiver Operating Characteristic Curve - ' + title)
  plt.legend(loc="lower right")
  plt.show()
  return accuracy,f1,auc,fpr,tpr

def getFeatureImportance(model, X_train):
  feat_importances = pd.Series(model.feature_importances_, index=X_train.columns).sort_values(ascending=False)
  print("Feature importance\n{}".format(feat_importances.round(2)))

def extendModels(models, title, acc, f1, auc, fpr, tpr):
  model = { 'model': title, 'acc': acc, 'f1': f1, 'auc': auc, 'fpr': fpr, 'tpr': tpr }
  models.append(model)
  return models

def compareModels(models):
  models = sorted(models, key=lambda k: k['acc'], reverse=True)
  sns.set(style="whitegrid")
  rcParams['figure.figsize'] = 15, 8
  plt.figure()

  for m in models:
    model = m['model']
    auc = m['auc']
    fpr = m['fpr']
    tpr = m['tpr']
    plt.plot(fpr, tpr, label='%s ROC-AUC = %.2f' % (model,auc))

  plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
  plt.title('Receiver Operating Characteristic Curve of Models')
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.legend(loc="lower right")
  plt.show()

  table = {'Evaluation':[]}
  for m in models:
    model = m['model']
    acc = round(m['acc'],2)
    f1 = round(m['f1'],2)
    row = {'Model': model, 'Accuracy': acc, 'F1-score': f1}
    table['Evaluation'].append(row)

  return json2html.convert(json = table)

def scheduler(epoch):
  if epoch < 10:
    return 0.001
  else:
    return 0.001 * tf.math.exp(0.1 * (10 - epoch))

def createGRU(X_train, units=256, dropout=0.2, activation='tanh', activation_2='sigmoid', init='glorot_uniform', optimizer='rmsprop', multi_layer=True):
  if units <= 0:
    units = 32
  if dropout <= 0:
    dropout = 0.2

  model = tf.keras.Sequential()

  if multi_layer:
    model.add(tf.keras.layers.GRU(units, input_shape=(X_train.shape[1], X_train.shape[2]), kernel_initializer=init, activation=activation, recurrent_dropout=float(dropout/2), return_sequences=True, reset_after=True))
    model.add(tf.keras.layers.Dropout(dropout))
    model.add(tf.keras.layers.GRU(units, kernel_initializer=init, activation=activation, recurrent_dropout=float(dropout/2), return_sequences=False, reset_after=False))
  else:
    model.add(tf.keras.layers.GRU(units, input_shape=(X_train.shape[1], X_train.shape[2]), kernel_initializer=init, activation=activation, recurrent_dropout=float(dropout/2), return_sequences=False, reset_after=False))
    
  model.add(tf.keras.layers.Dropout(dropout))
  model.add(tf.keras.layers.Flatten())
  model.add(tf.keras.layers.Dense(1))
  model.add(tf.keras.layers.Activation(activation_2))

  print(model.summary())
  model.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])
  return model

def LSTM_CNN(units=256, filters=64, kernel=3, pool=2, batch_size=128, dropout=0.1, init='random_uniform', cnn_activation='relu', padding='same', lstm_activation='tanh', activation='sigmoid', optimizer='rmsprop'):
  model = tf.keras.Sequential() 
  model.add(tf.keras.layers.Convolution1D(filters, kernel, padding=padding, activation=cnn_activation, input_shape=(X_train_t.shape[1], X_train_t.shape[2])))
  model.add(tf.keras.layers.MaxPooling1D(pool_size=(pool), padding=padding))
  model.add(tf.keras.layers.Convolution1D(filters/2, kernel, padding=padding, activation=cnn_activation))
  model.add(tf.keras.layers.MaxPooling1D(pool_size=(pool), padding=padding))
  model.add(tf.keras.layers.Dropout(dropout))
  model.add(tf.keras.layers.LSTM(units, kernel_initializer=init, activation=lstm_activation, recurrent_dropout=float(dropout/2), return_sequences=False))
  model.add(tf.keras.layers.Dropout(dropout))
  model.add(tf.keras.layers.Flatten())
  model.add(tf.keras.layers.Dense(1))
  model.add(tf.keras.layers.Activation(activation))
  model.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['acc'])
  return model

def normalize(dataset, title):
  from sklearn import preprocessing
  print("Normalization of dataset\n")

  label_col = dataset.label;
  dataset_without_labels = dataset.drop(columns=['label'])
  dataset_norm = dataset_without_labels
  names = dataset_norm.columns

  ss = preprocessing.StandardScaler()
  scaler = ss.fit(dataset_norm)
  scaled_dataset = scaler.transform(dataset_norm)
  scaled_dataset = pd.DataFrame(scaled_dataset, columns=names)
  dataset_norm.update(scaled_dataset)
  dataset_norm['label'] = label_col

  dataset = dataset_norm
  saveModel(scaler, title)
  print("Done")
  return dataset