import os
import pprint
import pandas as pd
import seaborn as sns
from pylab import rcParams

from psutil import virtual_memory
import tensorflow as tf

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
rcParams['figure.figsize'] = 15, 8
sns.set(style="whitegrid")

print("Tensorflow version " + tf.__version__)

try:
  tpu = tf.distribute.cluster_resolver.TPUClusterResolver()
  print('Running on TPU ', tpu.cluster_spec().as_dict()['worker'])
except ValueError:
  raise BaseException('ERROR: Not connected to a TPU runtime')

tf.config.experimental_connect_to_cluster(tpu)
tf.tpu.experimental.initialize_tpu_system(tpu)
tpu_strategy = tf.distribute.experimental.TPUStrategy(tpu)

ram_gb = virtual_memory().total / 1e9
print('Your runtime has {:.1f} gigabytes of available RAM\n'.format(ram_gb))

def tfPredict(model, X_train, y_train, X_valid, y_valid, X_test, y_test):
  tpu_model = tf.contrib.tpu.keras_to_tpu_model(model,strategy)
  model.compile(optimizer=tf.train.AdamOptimizer(learning_rate),
                loss=tf.keras.losses.categorical_crossentropy,
                metrics=['binary_accuracy'])
  out = tpu_model.fit(X_train, y_train, 
                      epochs=10, batch_size = 1024, verbose=2,
                      validation_data=[X_valid, y_valid])
  
  print('\nHistory:', out.history)
  print('\nEvaluation on test data\n')
  results = model.evaluate(x_test, y_test, batch_size=1024)
  print('Test [loss, acc]:', results)

root_path = '/content/drive/My Drive/Colab Notebooks/'
mydrive_path = 'drive/My Drive/Colab Notebooks/'
dataset_path = root_path + 'Dataset/'
preprocessed_dataset_path = root_path + 'PreprocessedDatasets/'
documentation_path = root_path + 'Documentation/'
resources_path = root_path + 'Resources/'
machine_learning_models_path = root_path + 'MachineLearningModels/'
notebooks_path = root_path + 'Notebooks/'